package mask

import (
	"bytes"
	"testing"
)

func TestEncryptDecryptRoundTrip(t *testing.T) {
	key, err := generateDEK()
	if err != nil {
		t.Fatal(err)
	}

	nonce, err := generateNonce()
	if err != nil {
		t.Fatal(err)
	}

	plaintext := []byte("sensitive personal information")

	ciphertext, err := encrypt(key, nonce, plaintext)
	if err != nil {
		t.Fatal(err)
	}

	if bytes.Equal(ciphertext, plaintext) {
		t.Fatal("ciphertext should not equal plaintext")
	}

	recovered, err := decrypt(key, nonce, ciphertext)
	if err != nil {
		t.Fatal(err)
	}

	if !bytes.Equal(recovered, plaintext) {
		t.Fatalf("got %q, want %q", recovered, plaintext)
	}
}

func TestWrapUnwrapKeyRoundTrip(t *testing.T) {
	kek, err := generateDEK() // master KEK is also 256-bit
	if err != nil {
		t.Fatal(err)
	}

	dek, err := generateDEK()
	if err != nil {
		t.Fatal(err)
	}

	wrapped, nonce, err := wrapKey(kek, dek)
	if err != nil {
		t.Fatal(err)
	}

	unwrapped, err := unwrapKey(kek, nonce, wrapped)
	if err != nil {
		t.Fatal(err)
	}

	if !bytes.Equal(unwrapped, dek) {
		t.Fatal("unwrapped DEK does not match original")
	}
}

func TestDecryptWithWrongKey(t *testing.T) {
	key1, _ := generateDEK()
	key2, _ := generateDEK()
	nonce, _ := generateNonce()

	ciphertext, err := encrypt(key1, nonce, []byte("secret"))
	if err != nil {
		t.Fatal(err)
	}

	_, err = decrypt(key2, nonce, ciphertext)
	if err == nil {
		t.Fatal("expected error decrypting with wrong key")
	}
}
