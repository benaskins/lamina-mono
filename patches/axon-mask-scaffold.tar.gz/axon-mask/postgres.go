package mask

import (
	"context"
	"database/sql"
	"errors"
	"fmt"
	"log/slog"
)

// PostgresVault implements Vault backed by PostgreSQL.
type PostgresVault struct {
	db  *sql.DB
	kek []byte // master key encryption key (256-bit)
}

// NewPostgresVault creates a vault backed by PostgreSQL.
// The kek must be exactly 32 bytes (AES-256).
func NewPostgresVault(db *sql.DB, kek []byte) (*PostgresVault, error) {
	if len(kek) != dekSize {
		return nil, fmt.Errorf("mask: KEK must be %d bytes, got %d", dekSize, len(kek))
	}
	return &PostgresVault{db: db, kek: kek}, nil
}

func (v *PostgresVault) Store(ctx context.Context, userID string, content []byte, opts ...StoreOption) (ContentRef, error) {
	cfg := applyStoreOpts(opts)

	// Get or create user's DEK
	dek, keyID, err := v.getOrCreateDEK(ctx, userID)
	if err != nil {
		return "", fmt.Errorf("mask: store: %w", err)
	}

	// Generate content ID and nonce
	ref, contentID, err := newContentRef()
	if err != nil {
		return "", err
	}
	nonce, err := generateNonce()
	if err != nil {
		return "", err
	}

	// Encrypt content
	ciphertext, err := encrypt(dek, nonce, content)
	if err != nil {
		return "", err
	}

	// Persist
	_, err = v.db.ExecContext(ctx,
		`INSERT INTO vault_content (id, user_id, key_id, nonce, ciphertext, expires_at)
		 VALUES ($1, $2, $3, $4, $5, $6)`,
		contentID, userID, keyID, nonce, ciphertext, cfg.expiresAt,
	)
	if err != nil {
		return "", fmt.Errorf("mask: store: insert: %w", err)
	}

	return ref, nil
}

func (v *PostgresVault) Retrieve(ctx context.Context, ref ContentRef) ([]byte, error) {
	contentID, err := parseRef(ref)
	if err != nil {
		return nil, err
	}

	var (
		userID     string
		keyID      string
		nonce      []byte
		ciphertext []byte
	)
	err = v.db.QueryRowContext(ctx,
		`SELECT c.user_id, c.key_id, c.nonce, c.ciphertext
		 FROM vault_content c
		 WHERE c.id = $1`,
		contentID,
	).Scan(&userID, &keyID, &nonce, &ciphertext)
	if errors.Is(err, sql.ErrNoRows) {
		return nil, ErrNotFound
	}
	if err != nil {
		return nil, fmt.Errorf("mask: retrieve: %w", err)
	}

	// Load and unwrap user's DEK
	dek, err := v.loadDEK(ctx, userID, keyID)
	if err != nil {
		return nil, err
	}

	return decrypt(dek, nonce, ciphertext)
}

func (v *PostgresVault) RetrieveBatch(ctx context.Context, refs []ContentRef) (map[ContentRef][]byte, error) {
	if len(refs) == 0 {
		return nil, nil
	}

	// Parse all refs
	ids := make([]string, 0, len(refs))
	refByID := make(map[string]ContentRef, len(refs))
	for _, ref := range refs {
		id, err := parseRef(ref)
		if err != nil {
			continue // skip invalid refs
		}
		ids = append(ids, id)
		refByID[id] = ref
	}

	// Query all content rows
	rows, err := v.db.QueryContext(ctx,
		`SELECT c.id, c.user_id, c.key_id, c.nonce, c.ciphertext
		 FROM vault_content c
		 WHERE c.id = ANY($1)`,
		ids,
	)
	if err != nil {
		return nil, fmt.Errorf("mask: retrieve batch: %w", err)
	}
	defer rows.Close()

	// Cache unwrapped DEKs for this batch
	dekCache := make(map[string][]byte) // key: userID+"/"+keyID

	result := make(map[ContentRef][]byte, len(refs))
	for rows.Next() {
		var (
			id         string
			userID     string
			keyID      string
			nonce      []byte
			ciphertext []byte
		)
		if err := rows.Scan(&id, &userID, &keyID, &nonce, &ciphertext); err != nil {
			return nil, fmt.Errorf("mask: retrieve batch: scan: %w", err)
		}

		cacheKey := userID + "/" + keyID
		dek, ok := dekCache[cacheKey]
		if !ok {
			dek, err = v.loadDEK(ctx, userID, keyID)
			if errors.Is(err, ErrErased) {
				continue // skip erased content
			}
			if err != nil {
				slog.Warn("mask: retrieve batch: skip item", "id", id, "error", err)
				continue
			}
			dekCache[cacheKey] = dek
		}

		plaintext, err := decrypt(dek, nonce, ciphertext)
		if err != nil {
			slog.Warn("mask: retrieve batch: decrypt failed", "id", id, "error", err)
			continue
		}

		if ref, ok := refByID[id]; ok {
			result[ref] = plaintext
		}
	}

	return result, rows.Err()
}

func (v *PostgresVault) EraseUser(ctx context.Context, userID string) error {
	_, err := v.db.ExecContext(ctx,
		`UPDATE vault_keys SET destroyed = true WHERE user_id = $1`,
		userID,
	)
	if err != nil {
		return fmt.Errorf("mask: erase user: %w", err)
	}
	slog.Info("mask: user erased", "user_id", userID)
	return nil
}

func (v *PostgresVault) DeleteContent(ctx context.Context, refs ...ContentRef) error {
	ids := make([]string, 0, len(refs))
	for _, ref := range refs {
		id, err := parseRef(ref)
		if err != nil {
			continue
		}
		ids = append(ids, id)
	}
	if len(ids) == 0 {
		return nil
	}
	_, err := v.db.ExecContext(ctx,
		`DELETE FROM vault_content WHERE id = ANY($1)`, ids)
	if err != nil {
		return fmt.Errorf("mask: delete content: %w", err)
	}
	return nil
}

func (v *PostgresVault) ExportUser(ctx context.Context, userID string) ([]ExportItem, error) {
	rows, err := v.db.QueryContext(ctx,
		`SELECT c.id, c.key_id, c.nonce, c.ciphertext, c.created_at, c.expires_at
		 FROM vault_content c
		 JOIN vault_keys k ON k.user_id = c.user_id AND k.key_id = c.key_id
		 WHERE c.user_id = $1 AND k.destroyed = false`,
		userID,
	)
	if err != nil {
		return nil, fmt.Errorf("mask: export user: %w", err)
	}
	defer rows.Close()

	dekCache := make(map[string][]byte)
	var items []ExportItem

	for rows.Next() {
		var item ExportItem
		var (
			id         string
			keyID      string
			nonce      []byte
			ciphertext []byte
		)
		if err := rows.Scan(&id, &keyID, &nonce, &ciphertext, &item.CreatedAt, &item.ExpiresAt); err != nil {
			return nil, fmt.Errorf("mask: export user: scan: %w", err)
		}

		dek, ok := dekCache[keyID]
		if !ok {
			dek, err = v.loadDEK(ctx, userID, keyID)
			if err != nil {
				return nil, fmt.Errorf("mask: export user: load key: %w", err)
			}
			dekCache[keyID] = dek
		}

		plaintext, err := decrypt(dek, nonce, ciphertext)
		if err != nil {
			return nil, fmt.Errorf("mask: export user: decrypt: %w", err)
		}

		item.Ref = ContentRef(refPrefix + id)
		item.Content = plaintext
		items = append(items, item)
	}

	return items, rows.Err()
}

func (v *PostgresVault) ReapExpired(ctx context.Context) (int64, error) {
	result, err := v.db.ExecContext(ctx,
		`DELETE FROM vault_content WHERE expires_at IS NOT NULL AND expires_at < now()`)
	if err != nil {
		return 0, fmt.Errorf("mask: reap expired: %w", err)
	}
	return result.RowsAffected()
}

// getOrCreateDEK returns the user's active DEK, creating one if it doesn't exist.
func (v *PostgresVault) getOrCreateDEK(ctx context.Context, userID string) (dek []byte, keyID string, err error) {
	// Try to load existing active key
	var wrappedKey, wrappedNonce []byte
	err = v.db.QueryRowContext(ctx,
		`SELECT key_id, wrapped_key, wrapped_nonce
		 FROM vault_keys
		 WHERE user_id = $1 AND destroyed = false
		 ORDER BY created_at DESC LIMIT 1`,
		userID,
	).Scan(&keyID, &wrappedKey, &wrappedNonce)

	if err == nil {
		dek, err = unwrapKey(v.kek, wrappedNonce, wrappedKey)
		return dek, keyID, err
	}
	if !errors.Is(err, sql.ErrNoRows) {
		return nil, "", fmt.Errorf("mask: get DEK: %w", err)
	}

	// Create new DEK
	dek, err = generateDEK()
	if err != nil {
		return nil, "", err
	}

	wrappedKey, wrappedNonce, err = wrapKey(v.kek, dek)
	if err != nil {
		return nil, "", err
	}

	ref, keyID, err := newContentRef()
	_ = ref // we only need the raw ID
	if err != nil {
		return nil, "", err
	}

	_, err = v.db.ExecContext(ctx,
		`INSERT INTO vault_keys (user_id, key_id, wrapped_key, wrapped_nonce)
		 VALUES ($1, $2, $3, $4)`,
		userID, keyID, wrappedKey, wrappedNonce,
	)
	if err != nil {
		return nil, "", fmt.Errorf("mask: create DEK: %w", err)
	}

	return dek, keyID, nil
}

// loadDEK loads and unwraps a specific DEK for a user.
func (v *PostgresVault) loadDEK(ctx context.Context, userID, keyID string) ([]byte, error) {
	var wrappedKey, wrappedNonce []byte
	var destroyed bool
	err := v.db.QueryRowContext(ctx,
		`SELECT wrapped_key, wrapped_nonce, destroyed FROM vault_keys WHERE user_id = $1 AND key_id = $2`,
		userID, keyID,
	).Scan(&wrappedKey, &wrappedNonce, &destroyed)
	if errors.Is(err, sql.ErrNoRows) {
		return nil, ErrNotFound
	}
	if err != nil {
		return nil, fmt.Errorf("mask: load DEK: %w", err)
	}
	if destroyed {
		return nil, ErrErased
	}
	return unwrapKey(v.kek, wrappedNonce, wrappedKey)
}
