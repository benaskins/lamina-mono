// Package mask provides a PII vault for the axon ecosystem.
//
// Content is encrypted with per-user data encryption keys (DEKs) wrapped
// by a master key encryption key (KEK). Destroying a user's DEK renders
// all their content permanently unreadable (crypto-shredding).
package mask

import (
	"context"
	"errors"
	"time"
)

// ContentRef is an opaque reference to vaulted content.
// Format: "mask:<content-id>" (e.g. "mask:cnt_a1b2c3d4e5f6").
type ContentRef string

// Vault stores, retrieves, and erases PII.
type Vault interface {
	// Store encrypts content under the user's DEK and returns an opaque ref.
	Store(ctx context.Context, userID string, content []byte, opts ...StoreOption) (ContentRef, error)

	// Retrieve decrypts a single content item.
	// Returns ErrErased if the user's key has been destroyed.
	// Returns ErrNotFound if the content ID does not exist.
	Retrieve(ctx context.Context, ref ContentRef) ([]byte, error)

	// RetrieveBatch decrypts multiple items in one round-trip.
	// Missing or erased refs are absent from the returned map (no error).
	RetrieveBatch(ctx context.Context, refs []ContentRef) (map[ContentRef][]byte, error)

	// EraseUser destroys all DEKs for the user, rendering their content
	// permanently unreadable. Ciphertext rows are left for async cleanup.
	EraseUser(ctx context.Context, userID string) error

	// DeleteContent removes specific content items (for retention reaping
	// or selective cleanup).
	DeleteContent(ctx context.Context, refs ...ContentRef) error

	// ExportUser decrypts and returns all content for a user, keyed by ref.
	// Used for Subject Access Requests (GDPR Article 15).
	ExportUser(ctx context.Context, userID string) ([]ExportItem, error)

	// ReapExpired deletes content past its expiry timestamp.
	// Returns the number of items reaped.
	ReapExpired(ctx context.Context) (int64, error)
}

// ExportItem is a single content item in a SAR export.
type ExportItem struct {
	Ref       ContentRef
	Content   []byte
	CreatedAt time.Time
	ExpiresAt *time.Time
}

// StoreOption configures a Store call.
type StoreOption func(*storeConfig)

type storeConfig struct {
	expiresAt *time.Time
}

// WithExpiry sets a TTL on the stored content. Content will be eligible
// for automatic reaping after the duration elapses.
func WithExpiry(d time.Duration) StoreOption {
	return func(c *storeConfig) {
		t := time.Now().Add(d)
		c.expiresAt = &t
	}
}

// WithExpiryAt sets an absolute expiry time on the stored content.
func WithExpiryAt(t time.Time) StoreOption {
	return func(c *storeConfig) {
		c.expiresAt = &t
	}
}

func applyStoreOpts(opts []StoreOption) storeConfig {
	var cfg storeConfig
	for _, o := range opts {
		o(&cfg)
	}
	return cfg
}

// Sentinel errors.
var (
	ErrErased   = errors.New("mask: user content has been erased")
	ErrNotFound = errors.New("mask: content not found")
)
