package mask

import (
	"crypto/rand"
	"encoding/hex"
	"fmt"
	"strings"
)

const refPrefix = "mask:"

// newContentRef generates a new random content reference.
func newContentRef() (ContentRef, string, error) {
	b := make([]byte, 16)
	if _, err := rand.Read(b); err != nil {
		return "", "", fmt.Errorf("mask: generate content ID: %w", err)
	}
	id := "cnt_" + hex.EncodeToString(b)
	return ContentRef(refPrefix + id), id, nil
}

// parseRef extracts the raw content ID from a ContentRef.
// Returns an error if the ref does not have the expected prefix.
func parseRef(ref ContentRef) (string, error) {
	s := string(ref)
	if !strings.HasPrefix(s, refPrefix) {
		return "", fmt.Errorf("mask: invalid ref prefix: %q", s)
	}
	return strings.TrimPrefix(s, refPrefix), nil
}
