package mask

import (
	"crypto/aes"
	"crypto/cipher"
	"crypto/rand"
	"errors"
	"fmt"
)

const (
	dekSize   = 32 // AES-256
	nonceSize = 12 // AES-GCM standard nonce
)

// generateDEK creates a new random 256-bit data encryption key.
func generateDEK() ([]byte, error) {
	dek := make([]byte, dekSize)
	if _, err := rand.Read(dek); err != nil {
		return nil, fmt.Errorf("mask: generate DEK: %w", err)
	}
	return dek, nil
}

// generateNonce creates a random 12-byte nonce for AES-GCM.
func generateNonce() ([]byte, error) {
	nonce := make([]byte, nonceSize)
	if _, err := rand.Read(nonce); err != nil {
		return nil, fmt.Errorf("mask: generate nonce: %w", err)
	}
	return nonce, nil
}

// encrypt encrypts plaintext with AES-256-GCM using the given key and nonce.
func encrypt(key, nonce, plaintext []byte) ([]byte, error) {
	block, err := aes.NewCipher(key)
	if err != nil {
		return nil, fmt.Errorf("mask: new cipher: %w", err)
	}
	gcm, err := cipher.NewGCM(block)
	if err != nil {
		return nil, fmt.Errorf("mask: new GCM: %w", err)
	}
	if len(nonce) != gcm.NonceSize() {
		return nil, errors.New("mask: nonce size mismatch")
	}
	return gcm.Seal(nil, nonce, plaintext, nil), nil
}

// decrypt decrypts ciphertext with AES-256-GCM using the given key and nonce.
func decrypt(key, nonce, ciphertext []byte) ([]byte, error) {
	block, err := aes.NewCipher(key)
	if err != nil {
		return nil, fmt.Errorf("mask: new cipher: %w", err)
	}
	gcm, err := cipher.NewGCM(block)
	if err != nil {
		return nil, fmt.Errorf("mask: new GCM: %w", err)
	}
	if len(nonce) != gcm.NonceSize() {
		return nil, errors.New("mask: nonce size mismatch")
	}
	plaintext, err := gcm.Open(nil, nonce, ciphertext, nil)
	if err != nil {
		return nil, fmt.Errorf("mask: decrypt: %w", err)
	}
	return plaintext, nil
}

// wrapKey encrypts a DEK with the master KEK using AES-256-GCM.
func wrapKey(kek, dek []byte) ([]byte, []byte, error) {
	nonce, err := generateNonce()
	if err != nil {
		return nil, nil, err
	}
	wrapped, err := encrypt(kek, nonce, dek)
	if err != nil {
		return nil, nil, fmt.Errorf("mask: wrap key: %w", err)
	}
	return wrapped, nonce, nil
}

// unwrapKey decrypts a DEK with the master KEK.
func unwrapKey(kek, nonce, wrappedDEK []byte) ([]byte, error) {
	dek, err := decrypt(kek, nonce, wrappedDEK)
	if err != nil {
		return nil, fmt.Errorf("mask: unwrap key: %w", err)
	}
	return dek, nil
}
