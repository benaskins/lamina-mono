CREATE TABLE IF NOT EXISTS vault_keys (
    user_id       TEXT NOT NULL,
    key_id        TEXT NOT NULL,
    wrapped_key   BYTEA NOT NULL,
    wrapped_nonce BYTEA NOT NULL,
    created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
    destroyed     BOOLEAN NOT NULL DEFAULT false,

    PRIMARY KEY (user_id, key_id)
);

CREATE TABLE IF NOT EXISTS vault_content (
    id          TEXT PRIMARY KEY,
    user_id     TEXT NOT NULL,
    key_id      TEXT NOT NULL,
    nonce       BYTEA NOT NULL,
    ciphertext  BYTEA NOT NULL,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    expires_at  TIMESTAMPTZ,

    FOREIGN KEY (user_id, key_id) REFERENCES vault_keys(user_id, key_id)
);

CREATE INDEX IF NOT EXISTS idx_vault_content_user
    ON vault_content(user_id);

CREATE INDEX IF NOT EXISTS idx_vault_content_expires
    ON vault_content(expires_at)
    WHERE expires_at IS NOT NULL;

CREATE INDEX IF NOT EXISTS idx_vault_keys_destroyed
    ON vault_keys(user_id)
    WHERE destroyed = true;
