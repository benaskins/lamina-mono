package mask

import "context"

// Resolver hydrates content references from the vault. It is designed
// to be embedded in service handlers that need to resolve refs at read time.
type Resolver struct {
	Vault Vault
}

// Resolve fetches a single ref. Returns the placeholder string if the
// content has been erased or is not found.
func (r *Resolver) Resolve(ctx context.Context, ref string, placeholder string) string {
	if ref == "" {
		return ""
	}
	b, err := r.Vault.Retrieve(ctx, ContentRef(ref))
	if err != nil {
		return placeholder
	}
	return string(b)
}

// ResolveBatch fetches multiple refs in one round-trip and returns a map
// from ref string to plaintext. Missing/erased refs are mapped to the
// placeholder string.
func (r *Resolver) ResolveBatch(ctx context.Context, refs []string, placeholder string) map[string]string {
	if len(refs) == 0 {
		return nil
	}

	crefs := make([]ContentRef, 0, len(refs))
	for _, s := range refs {
		if s != "" {
			crefs = append(crefs, ContentRef(s))
		}
	}

	resolved, err := r.Vault.RetrieveBatch(ctx, crefs)
	if err != nil {
		// On error, return placeholders for everything
		m := make(map[string]string, len(refs))
		for _, s := range refs {
			if s != "" {
				m[s] = placeholder
			}
		}
		return m
	}

	m := make(map[string]string, len(refs))
	for _, s := range refs {
		if s == "" {
			continue
		}
		if b, ok := resolved[ContentRef(s)]; ok {
			m[s] = string(b)
		} else {
			m[s] = placeholder
		}
	}
	return m
}
