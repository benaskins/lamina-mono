module github.com/benaskins/axon-mask

go 1.26.1
